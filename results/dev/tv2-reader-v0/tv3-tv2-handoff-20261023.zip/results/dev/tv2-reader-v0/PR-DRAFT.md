# TV3: Reader benchmark trên dữ liệu validation TV2 và bàn giao evidence

TV2 PR #60 đã có PNG/PDF nhưng manifest CSV chưa chạy trực tiếp với Reader benchmark.
Thay đổi thêm importer chỉ nhận validation, khóa checksum/provenance và giữ UUID nguồn;
chạy paired OCR-all/route-aware trên 27 tài liệu của ba parent, lưu raw evidence,
route/timing và sáu ví dụ lỗi để TV2/TV4 liên kết gold. CI bao phủ importer/paired tools.

Validation: 91 unit/contract tests và Ruff đạt; 54/54 real Reader/KIE runs qua
TV3/TV4/TV5 provider contracts; patch source kiểm tra apply trên snapshot main đã đọc.
Kết quả là diagnostics từ transcript SVG nguồn chưa duyệt, một layout validation,
không phải final benchmark hoặc KIE accuracy. Labels TV2 còn thiếu headers, unit in
gold không có trên nguồn và chưa aligned evidence; Docker ARM64 scan chưa xác minh.

Refs #48; dữ liệu cố định PR #60 commit 5e5b871dd1c7413f2d74acc175aad0f0186486f7.
Không đóng issue; local archive không có .git. Đây là nội dung draft để review,
chưa tạo pull request hoặc gửi thông điệp GitHub.
