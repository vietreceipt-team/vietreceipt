# TV3 / TV2 development evidence handoff

Đọc docs/tv3-tv2-synthetic-v0.md trong gói hoặc workspace để xem kết quả và giới hạn.
ZIP giữ đường dẫn tương đối project. Giải nén vào thư mục mới để review.

- inputs-20261023: 27 validation documents, source SVG/labels, locked manifest.
- git-source-text + source-transfer ledger: original LF Git blobs vs CRLF checkout bytes.
- paired-20261023: both modes, raw document-2.0 evidence/metadata, metrics, handoff.
- contracts-20261023: real TV4 KIE outputs plus TV3/TV4/TV5 validation records.
- failure-examples: six honest reviewed diagnostic examples, no verified-gold claim.
- preview-* directories: local source/polygon inspection pages; no extra OCR pass.
- source-snapshot + model-provenance: actual inference sources and hashes.
- tv3-source-changes.patch: source changes vs inspected main 061960f0; data not in patch.
- PR-DRAFT.md: concrete review text; nothing published or messaged on GitHub.

All source gold still awaits TV2 correction/QA and run-specific block alignment.
No train/test documents read. No Docker/end-to-end deployment claim.
