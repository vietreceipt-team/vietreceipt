"""Copy pinned development assets and reconstruct hash-checked validation transcripts only."""
import csv
import hashlib
import importlib
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile

REF = '89281198ebaf419e511b4c99321ca3355e94fcf1'
ROOT = Path('.tv3-tmp/pr66-8928119')

def get(path):
    return subprocess.check_output(['git', 'show', f'{REF}:{path}'])

ROOT.mkdir(parents=True, exist_ok=False)
for path in ('data/handoffs/tv4-dev-v1.zip', 'data/handoffs/tv4-dev-v1.package.json',
             'data/manifests/synthetic_v0.2.0/base.csv',
             'data/manifests/synthetic_v0.2.0/validation.csv',
             'data/manifests/synthetic_v0.2.0/variants.csv',
             'data/synthetic/fixtures_v0.2.0/generation.json',
             'scripts/data/generate_synthetic.py', 'scripts/data/common.py'):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(get(path))
for path in ('scripts/__init__.py', 'scripts/data/__init__.py'):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text('', encoding='utf-8')
archive = ROOT / 'data/handoffs/tv4-dev-v1.zip'
package = json.loads(archive.with_suffix('.package.json').read_text(encoding='utf-8'))
assert hashlib.sha256(archive.read_bytes()).hexdigest() == package['archive_sha256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    names = z.namelist()
    print('archive entries', len(names), 'first', names[:12])
    # The entire archive is development-only. Sources are read later only for validation records.
    z.extractall(ROOT / 'handoff')
registry = list(csv.DictReader(io.StringIO((ROOT / 'data/manifests/synthetic_v0.2.0/base.csv').read_text(encoding='utf-8'))))
sys.path.insert(0, str(ROOT.resolve()))
module = importlib.import_module('scripts.data.generate_synthetic')
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
font = Path('C:/Windows/Fonts/arial.ttf')
generation = json.loads((ROOT / 'data/synthetic/fixtures_v0.2.0/generation.json').read_text(encoding='utf-8'))
assert hashlib.sha256(font.read_bytes()).hexdigest() == generation['font_sha256']
pdfmetrics.registerFont(TTFont('TV2Reconstruction', str(font)))
ledger = []
for row in registry:
    if row['split'] != 'validation':
        continue
    sid = row['sample_id']
    gold, rate = module.make_gold(int(sid.rsplit('-',1)[1]), row['layout_id'], generation['seed'])
    spec = module.render_spec(gold, rate, 'TV2Reconstruction')
    text = ('\n'.join(e['text'] for e in spec['entries']) + '\n').encode('utf-8')
    assert hashlib.sha256(text).hexdigest() == row['transcript_sha256'], sid
    target = ROOT / 'transcript-source' / row['transcript_path']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(text)
    spec_path = ROOT / 'transcript-source' / row['render_spec_path']
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    spec_path.write_text(json.dumps(spec, ensure_ascii=False, indent=2)+'\n',encoding='utf-8')
    ledger.append({'sample_id': sid, 'sha256': hashlib.sha256(text).hexdigest(), 'matches_published_base_csv': True})
report = {'source_commit': REF, 'archive_sha256': package['archive_sha256'],
          'method': 'Pinned TV2 generator render_spec visible entries; seed/font pinned; only validation reconstructed',
          'not_derived_from': ['Reader output', 'KIE predictions', 'PDF text extraction'],
          'human_verified': False, 'font_sha256': generation['font_sha256'], 'seed': generation['seed'],
          'source_sha256': {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ('scripts/data/generate_synthetic.py','scripts/data/common.py')},
          'transcripts': ledger}
(ROOT/'transcript-source/reconstruction.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=True, indent=2))
